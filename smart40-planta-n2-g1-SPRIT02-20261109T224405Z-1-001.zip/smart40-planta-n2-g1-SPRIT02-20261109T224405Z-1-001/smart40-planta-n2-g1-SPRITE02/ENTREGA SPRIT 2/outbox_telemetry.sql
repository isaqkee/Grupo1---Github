-- Script de Criação do Banco Local SQLite - Store-and-Forward Outbox Pattern
-- Projeto Estação Smart 4.0 (Sprint 2 - Grupo 1)

CREATE TABLE IF NOT EXISTS outbox_telemetry (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id VARCHAR(50) NOT NULL DEFAULT 'PLANT_N2_EDGE_01',
    topic VARCHAR(100) NOT NULL DEFAULT 'smart40/n2/telemetry',
    payload JSON NOT NULL,
    qos INTEGER NOT NULL DEFAULT 1,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING', -- PENDING, SENT, FAILED
    retry_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    sent_at TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_outbox_status ON outbox_telemetry(status);
CREATE INDEX IF NOT EXISTS idx_outbox_created_at ON outbox_telemetry(created_at);
