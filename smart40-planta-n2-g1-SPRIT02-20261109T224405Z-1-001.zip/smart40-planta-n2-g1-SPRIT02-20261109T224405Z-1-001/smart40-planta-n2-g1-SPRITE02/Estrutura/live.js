export class LiveAdapter {
  constructor({ url }) { this.url = url; }
  async start({ onData, onStatus }) {
    onStatus({ connection: 'connecting' });
    this.es = new EventSource(this.url);
    this.es.onopen    = () => onStatus({ connection: 'connected' });
    this.es.onerror   = () => onStatus({ connection: 'reconnecting' });
    this.es.onmessage = e => onData(JSON.parse(e.data));
  }
  async stop() { this.es?.close(); }
}