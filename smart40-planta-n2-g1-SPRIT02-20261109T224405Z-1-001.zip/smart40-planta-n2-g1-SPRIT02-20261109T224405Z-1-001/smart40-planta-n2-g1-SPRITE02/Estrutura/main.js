import { createScene } from './scene/createScene.js';
import { createStore } from './domain/store.js';
import { SimAdapter } from './adapters/sim.js';
import { LiveAdapter } from './adapters/live.js';
import { ReplayAdapter } from './adapters/replay.js';

const view = createScene(document.querySelector('#twin'));
const store = createStore();
const factories = {
  sim:    o => new SimAdapter(o),
  live:   o => new LiveAdapter(o),
  replay: o => new ReplayAdapter(o)
};
let active = null;
let generation = 0;

export async function switchMode(mode, options = {}) {
  if (!factories[mode]) throw new Error('Modo inválido');
  const token = ++generation;
  await active?.stop();
  if (token !== generation) return;

  store.reset();
  view.reset();
  const adapter = factories[mode](options);
  active = adapter;
  view.setStatus({ mode, connection: 'connecting' });

  try {
    await adapter.start({
      onData:   env     => { if (token === generation) store.apply(env); },
      onStatus: status  => { if (token === generation) view.setStatus({ mode, ...status }); }
    });
  } catch {
    if (token === generation) view.setStatus({ mode, connection: 'error' });
  }
}

view.start(() => store.snapshot());
await switchMode('sim');