export class SimAdapter {
  constructor({ periodMs = 100 } = {}) { this.periodMs = periodMs; }
  async start({ onData }) {
    let seq = 0, t = 0;
    const quality = { status: 'GOOD', source_code: 'SIM_OK', reason: null };
    this.timer = setInterval(() => {
      t += this.periodMs / 1000;
      const base = {
        schema_version: '1.0', origin: 'simulado', quality,
        stream_id: 'sim', unit_id: 'UNIDADE_DEMO', asset_id: 'N2_DEMO',
        timestamps: { source_utc: null, gateway_utc: null, ingest_utc: null,
                      emitted_utc: new Date(0).toISOString(), source_uptime_s: null },
        context: { sim_time_s: t, map_version: 'draft-1', model_version: 'demo-1' }
      };
      onData({ ...base, seq: seq++, tag: 'machine.state',
               value: 'executando', value_type: 'string', unit: null });
      onData({ ...base, seq: seq++, tag: 'robot.joint_position',
               value: [0, -1.2 + 0.2 * Math.sin(t), 1.4, -1.7, 0.9, 0],
               value_type: 'float64[6]', unit: 'rad' });
    }, this.periodMs);
  }
  async stop() { clearInterval(this.timer); }
}