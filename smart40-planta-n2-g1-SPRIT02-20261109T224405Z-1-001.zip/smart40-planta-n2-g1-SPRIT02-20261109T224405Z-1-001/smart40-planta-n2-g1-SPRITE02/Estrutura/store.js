import { validateEnvelope } from './contract.js';

export function createStore() {
  const tags = new Map();          // tag -> último envelope válido
  const lastSeq = new Map();       // stream_id -> maior seq aplicado

  return {
    reset() { tags.clear(); lastSeq.clear(); },
    apply(env) {
      const e = validateEnvelope(env);
      const last = lastSeq.get(e.stream_id) ?? -1;
      if (e.seq <= last) return false;   // duplicata (QoS 1) ou fora de ordem
      lastSeq.set(e.stream_id, e.seq);
      tags.set(e.tag, e);
      return true;
    },
    snapshot() {
      return {
        tags: Object.fromEntries(tags),
        at: Date.now()
      };
    }
  };
}