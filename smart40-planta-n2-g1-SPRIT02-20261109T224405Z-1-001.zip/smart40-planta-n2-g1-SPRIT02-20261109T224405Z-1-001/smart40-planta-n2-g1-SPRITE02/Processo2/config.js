// config.js — Nenhum endereço industrial no código 3D.
// Tudo que muda entre unidades fica aqui.

export const config = {
  unitId: process.env.UNIT_ID ?? "UNIDADE-XX",

  opcua: {
    endpoint: process.env.OPCUA_ENDPOINT ?? "opc.tcp://192.168.0.10:4840",
    securityPolicy: process.env.OPCUA_SECURITY ?? "None", // evoluir para Basic256Sha256
    securityMode: process.env.OPCUA_MODE ?? "None",
    // Credenciais via variável de ambiente — nunca em arquivo versionado
    user: process.env.OPCUA_USER ?? "",
    password: process.env.OPCUA_PASSWORD ?? "",
    sessionTimeoutMs: 30_000,
  },

  // Mapa de tags: nome semântico -> NodeId do CLP.
  // É o ÚNICO lugar que conhece endereços do equipamento.
  tags: {
    "estado_maquina":        'ns=3;s="DB_ESTADO"."estado"',
    "contador_ciclos":       'ns=3;s="DB_ESTADO"."contadorCiclos"',
    "ordem_atual":           'ns=3;s="DB_MES"."ordemAtual"',
    "falha_ativa":           'ns=3;s="DB_DIAG"."falhaAtiva"',
    "codigo_falha":          'ns=3;s="DB_DIAG"."codigoFalha"',
  },

  subscription: {
    publishingIntervalMs: 500,
    // Quanto maior a mudança relativa, maior o filtro de deadband
    deadbandPercent: 1.0,
  },

  ws: {
    backendUrl: process.env.BACKEND_WS_URL ?? "wss://backend.exemplo.com/telemetry",
    // Reconexão exponencial
    reconnectBaseMs: 1000,
    reconnectMaxMs: 30_000,
    // Buffer local para sobreviver a queda de rede
    bufferMaxEvents: 10_000,
  },
};