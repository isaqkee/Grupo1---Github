// index.js — monta o pipeline: OPC UA -> normalização -> WebSocket.

import { connectOpcua } from "./opcuaClient.js";
import { createSubscription } from "./subscription.js";
import { createWsBridge } from "./wsBridge.js";
import { config } from "./config.js";

const bridge = createWsBridge();

let currentSession = null;

function normalizeAndEmit(raw) {
  // O envelope completo é montado aqui — ver contrato na seção 2.
  bridge.send({
    unitId: config.unitId,
    assetId: "bancada-smart40",       // fixo por gateway; multi-ativo = multi-gateway
    tag: raw.tag,
    value: raw.value,
    unit: null,                       // preencher no mapa de tags quando aplicável
    sourceTimestamp: raw.sourceTimestamp,
    receivedTimestamp: new Date().toISOString(),
    sequence: raw.sequence,
    quality: raw.statusCode,
    origin: "medido",                 // gateway só publica leitura física
  });
}

connectOpcua(
  (session) => {
    currentSession = session;
    createSubscription(session, normalizeAndEmit);
    console.log(`[gateway] sessão ativa: ${config.opcua.endpoint}`);
  },
  (err) => {
    console.error(`[gateway] ${new Date().toISOString()} — ${err.message}`);
  }
);

// Health check local para o gerenciador de processo (systemd, PM2 etc.)
setInterval(() => {
  console.log(`[gateway] ws=${bridge.status} sessao=${currentSession ? "ativa" : "inativa"}`);
}, 30_000);