// gateway.js — leitura periódica de tags, somente leitura
import { OPCUAClient } from "node-opcua";

const client = OPCUAClient.create({ endpointMustExist: false });
await client.connect("opc.tcp://IP_DO_CLP:4840");
const session = await client.createSession();

setInterval(async () => {
  const valores = await session.read([
    { nodeId: "ns=3;s=\"Estado_Esteira\"", attributeId: 14 }, // Valor
    { nodeId: "ns=3;s=\"Contador_Pecas\"", attributeId: 14 },
  ]);
  // publicar via WebSocket/SSE para o frontend
}, 500);