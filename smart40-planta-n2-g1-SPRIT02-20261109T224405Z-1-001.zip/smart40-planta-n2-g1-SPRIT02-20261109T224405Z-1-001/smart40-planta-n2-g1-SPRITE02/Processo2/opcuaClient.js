// opcuaClient.js — conexão OPC UA com reconexão e backoff.
// Somente leitura: o gateway nunca escreve no CLP.

import { OPCUAClient, ClientSession, MessageSecurityMode,
         SecurityPolicy, AttributeIds } from "node-opcua";
import { config } from "./config.js";

const RECONNECT_BASE_MS = 2_000;
const RECONNECT_MAX_MS = 60_000;

export async function connectOpcua(onReady, onError) {
  let attempt = 0;
  let stopped = false;

  const client = OPCUAClient.create({
    endpointMustExist: false,
    securityMode: MessageSecurityMode[config.opcua.securityMode],
    securityPolicy: SecurityPolicy[config.opcua.securityPolicy],
    requestedSessionTimeout: config.opcua.sessionTimeoutMs,
    // Sessão ativa deve manter-se viva; keepalive evita drop silencioso
    keepSessionAlive: true,
  });

  async function connect() {
    if (stopped) return;
    try {
      await client.connect(config.opcua.endpoint);

      const session = await client.createSession(
        config.opcua.user
          ? {
              userName: config.opcua.user,
              password: config.opcua.password,
            }
          : { type: 0 } // anonymous
      );

      attempt = 0;
      onReady(session);

      // Reconexão de sessão: node-opcua emite os eventos abaixo
      client.on("connection_lost", () => onError(new Error("conexao perdida")));
      client.on("backoff", () => {});
      client.on("connection_reestablished", () => onReady(session));
    } catch (err) {
      const delay = Math.min(RECONNECT_BASE_MS * 2 ** attempt, RECONNECT_MAX_MS);
      attempt += 1;
      onError(err);
      setTimeout(connect, delay);
    }
  }

  connect();

  return {
    async shutdown() {
      stopped = true;
      try { await client.disconnect(); } catch { /* já desconectado */ }
    },
  };
}