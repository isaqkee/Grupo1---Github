// subscription.js — cria a subscrição e monitora as tags do mapa.
// Emite eventos normalizados para o barramento interno do gateway.

import { TimestampsToReturn, MonitoringParameters,
         DataChangeFilter, DataChangeTrigger, DeadbandType } from "node-opcua";
import { config } from "./config.js";

export function createSubscription(session, emit) {
  const sub = session.createSubscription2({
    requestedPublishingInterval: config.subscription.publishingIntervalMs,
    requestedLifetimeCount: 100,
    requestedMaxKeepAliveCount: 10,
    maxNotificationsPerPublish: 100,
    publishingEnabled: true,
    priority: 10,
  });

  let sequence = 0;

  for (const [tagName, nodeId] of Object.entries(config.tags)) {
    const item = sub.monitor(
      {
        nodeId,
        attributeId: AttributeIds.Value,
      },
      {
        samplingInterval: config.subscription.publishingIntervalMs,
        discardOldest: true,
        queueSize: 100,
      },
      TimestampsToReturn.Both
    );

    item.on("changed", (dataValue) => {
      sequence += 1;
      emit({
        tag: tagName,
        value: dataValue.value.value,
        dataType: dataValue.value.dataType?.key ?? "Unknown",
        sourceTimestamp: dataValue.sourceTimestamp?.toISOString() ?? null,
        serverTimestamp: dataValue.serverTimestamp?.toISOString() ?? null,
        statusCode: dataValue.statusCode?.key ?? "Good",
        sequence,
      });
    });

    item.on("error", (err) => {
      // Falha em um item não derruba a subscrição inteira
      emit({
        tag: tagName,
        value: null,
        dataType: "Error",
        sourceTimestamp: new Date().toISOString(),
        serverTimestamp: null,
        statusCode: "BadInternalError",
        sequence: ++sequence,
        diagnostic: String(err?.message ?? err),
      });
    });
  }

  return sub;
}