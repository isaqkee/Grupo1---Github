// wsBridge.js — envia eventos ao backend via WebSocket.
// Garante: reconexão exponencial, reenvio do buffer e marcação de lacunas.

import WebSocket from "ws";
import { config } from "./config.js";

export function createWsBridge() {
  let socket = null;
  let connected = false;
  let attempt = 0;
  const buffer = [];
  let gapDetected = false; // true quando houve perda durante desconexão

  function scheduleReconnect() {
    const delay = Math.min(
      config.ws.reconnectBaseMs * 2 ** attempt,
      config.ws.reconnectMaxMs
    );
    attempt += 1;
    setTimeout(connect, delay);
  }

  function connect() {
    socket = new WebSocket(config.ws.backendUrl, {
      // Token de autenticação do gateway — provisionado pelo backend
      headers: { Authorization: `Bearer ${process.env.GATEWAY_TOKEN ?? ""}` },
    });

    socket.on("open", () => {
      connected = true;
      attempt = 0;

      // 1. Se houve lacuna, avisa o backend ANTES de reenviar o buffer
      if (gapDetected) {
        socket.send(JSON.stringify({
          type: "gap",
          unitId: config.unitId,
          bufferedEvents: buffer.length,
        }));
        gapDetected = false;
      }

      // 2. Reenvia buffer em ordem (com limite por lote para não saturar)
      while (buffer.length > 0) {
        const batch = buffer.splice(0, 100);
        socket.send(JSON.stringify({ type: "batch", events: batch }));
      }
    });

    socket.on("close", () => {
      connected = false;
      scheduleReconnect();
    });

    socket.on("error", () => {
      // O evento "close" seguinte dispara a reconexão
      connected = false;
    });
  }

  connect();

  return {
    send(event) {
      if (connected && socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ type: "event", event }));
      } else {
        gapDetected = true;
        if (buffer.length < config.ws.bufferMaxEvents) {
          buffer.push(event);
        }
        // Buffer cheio: descarta o mais antigo (política configurável)
        else buffer.shift();
      }
    },
    get status() {
      return connected ? "online" : "offline";
    },
  };
}