import test from 'node:test';
import assert from 'node:assert/strict';
import { validateEnvelope } from '../packages/shared/src/validate.js';
import { SimAdapter } from '../packages/web/src/adapters/sim.js';
import { createStore } from '../packages/web/src/domain/store.js';

test('fluxo sim -> store respeita contrato e deduplicação', async () => {
  const store = createStore();
  const adapter = new SimAdapter({ periodMs: 10 });
  let applied = 0, rejected = 0;

  await adapter.start({
    onData: env => {
      try { if (store.apply(validateEnvelope(env))) applied++; else rejected++; }
      catch { rejected++; }
    }
  });

  await new Promise(r => setTimeout(r, 200));
  await adapter.stop();

  assert.ok(applied > 0, 'deve aplicar envelopes válidos');
  assert.equal(rejected, 0, 'nenhum envelope do simulador pode violar o contrato');
  const snap = store.snapshot();
  assert.equal(snap.tags['machine.state'].origin, 'simulado');
});