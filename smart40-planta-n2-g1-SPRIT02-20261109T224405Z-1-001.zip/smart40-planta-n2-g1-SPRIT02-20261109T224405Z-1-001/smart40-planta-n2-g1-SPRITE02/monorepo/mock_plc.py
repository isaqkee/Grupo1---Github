import asyncio, random
from asyncua import Server

async def main():
    server = Server()
    await server.init()
    server.set_endpoint("opc.tcp://0.0.0.0:4840/n2/mock")
    idx = await server.register_namespace("http://n2.local/mock")
    obj = await server.nodes.objects.add_object(idx, "Machine")
    state = await obj.add_variable(idx, "State", 0)
    part = await obj.add_variable(idx, "PartPresent", False)
    # Somente leitura: variáveis NÃO são writable
    logger = server.logger
    cycle = 0
    async with server:
        while True:
            cycle = (cycle + 1) % 4          # 0=parada 1=pronta 2=executando 3=alarme
            await state.write_value(cycle)
            await part.write_value(random.random() > 0.3)
            logger.info("mock-plc state=%s part=%s", cycle, await part.read_value())
            await asyncio.sleep(2)

asyncio.run(main())