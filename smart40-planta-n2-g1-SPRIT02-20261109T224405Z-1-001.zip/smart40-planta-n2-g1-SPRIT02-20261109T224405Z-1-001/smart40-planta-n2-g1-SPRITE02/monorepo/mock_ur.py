import asyncio, json, math

async def handle(reader, writer):
    t = 0.0
    try:
        while True:
            t += 0.1
            packet = {
                "timestamp": t,                      # uptime do controlador (mock)
                "actual_q": [round(0.2 * math.sin(t + i), 4) for i in range(6)],
                "actual_TCP_pose": [0.4, 0.1, 0.3, 0.0, 0.0, 1.57],
                "runtime_state": 2
            }
            writer.write((json.dumps(packet) + "\n").encode())
            await writer.drain()
            await asyncio.sleep(0.1)
    except ConnectionError:
        pass

async def main():
    server = await asyncio.start_server(handle, "0.0.0.0", 30004)
    async with server:
        await server.serve_forever()

asyncio.run(main())