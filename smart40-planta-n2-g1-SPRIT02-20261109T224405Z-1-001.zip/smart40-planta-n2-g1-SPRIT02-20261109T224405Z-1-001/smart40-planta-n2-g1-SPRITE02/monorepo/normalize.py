import time, uuid

def normalize(tag: str, value, value_type: str, unit, origin: str,
              source_ts, stream_id: str, seq: int,
              unit_id: str, asset_id: str, component_id: str) -> dict:
    return {
        "schema_version": "1.0",
        "message_id": f"{stream_id}:{seq}",
        "unit_id": unit_id,
        "asset_id": asset_id,
        "component_id": component_id,
        "tag": tag,
        "value": value,
        "value_type": value_type,
        "unit": unit,
        "origin": origin,
        "timestamps": {
            "source_utc": source_ts,
            "gateway_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "ingest_utc": None,
            "emitted_utc": None,
            "source_uptime_s": None
        },
        "quality": {"status": "GOOD", "source_code": "MOCK_OK", "reason": None},
        "stream_id": stream_id,
        "seq": seq
    }