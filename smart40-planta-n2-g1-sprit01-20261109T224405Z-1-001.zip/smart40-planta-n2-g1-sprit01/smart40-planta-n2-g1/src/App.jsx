import { useEffect, useState } from 'react'
import { Routes, Route, NavLink, Outlet, Link, useOutletContext } from 'react-router'
import Sprint from './pages/Sprint.jsx'
import Hmi from './pages/Hmi.jsx'
import Orders from './pages/Orders.jsx'
import Dashboard from './pages/Dashboard.jsx'

const CORE_LINKS = [
  ['/', 'Checklist'],
  ['/hmi', 'IHM'],
]
const EXTRA_LINKS = [
  ['/orders', 'Ordens'],
  ['/dashboard', 'Dashboard'],
]
const EXTRAS_KEY = 'smart40:extras'

function loadExtras() {
  try {
    return localStorage.getItem(EXTRAS_KEY) === 'on'
  } catch {
    return false
  }
}

function Layout() {
  const [extras, setExtras] = useState(loadExtras)

  useEffect(() => {
    try {
      localStorage.setItem(EXTRAS_KEY, extras ? 'on' : 'off')
    } catch {
      /* sem armazenamento: segue sem persistir */
    }
  }, [extras])

  const links = extras ? [...CORE_LINKS, ...EXTRA_LINKS] : CORE_LINKS

  return (
    <div className="min-h-screen">
      <header className="bg-ink text-paper">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-5 py-4">
          <div>
            <p className="font-display text-2xl font-bold leading-none">SMART 4.0 • Planta N2</p>
            <p className="mt-1 text-sm text-paper/70">Grupo 1 — IoT / CLP • base da Sprint 1</p>
          </div>
          <nav className="flex flex-wrap gap-1" aria-label="Principal">
            {links.map(([to, label]) => (
              <NavLink
                key={to}
                to={to}
                end={to === '/'}
                className={({ isActive }) =>
                  'rounded px-3 py-2 text-sm font-medium ' +
                  (isActive ? 'bg-amber text-ink' : 'text-paper hover:bg-white/10')
                }
              >
                {label}
              </NavLink>
            ))}
          </nav>
        </div>
      </header>
      <div className="border-b border-amber/60 bg-amber/20">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-5 py-2 text-sm">
          <p>
            Dados simulados. Esta aplicação não se conecta ao CLP, ao robô nem a qualquer banco, e não substitui a parada de emergência física.
          </p>
          <label className="flex cursor-pointer items-center gap-2 font-medium">
            <input
              type="checkbox"
              checked={extras}
              onChange={(e) => setExtras(e.target.checked)}
              className="h-4 w-4 accent-ink"
            />
            Mostrar módulos opcionais
          </label>
        </div>
      </div>
      <main className="mx-auto max-w-6xl px-5 py-8">
        <Outlet context={{ extras, setExtras }} />
      </main>
    </div>
  )
}

function Optional({ name, children }) {
  const { extras, setExtras } = useOutletContext()
  if (extras) return children
  return (
    <div>
      <h1 className="font-display text-4xl font-bold">{name} é um módulo opcional</h1>
      <p className="mt-2 max-w-prose text-steel">
        Fora do escopo do Grupo 1, por isso fica desativado. Ative para ver os dados de exemplo.
      </p>
      <button
        onClick={() => setExtras(true)}
        className="mt-4 rounded bg-ink px-4 py-2 text-sm font-semibold text-paper"
      >
        Ativar módulos opcionais
      </button>
    </div>
  )
}

function NotFound() {
  return (
    <div>
      <h1 className="font-display text-4xl font-bold">Rota não encontrada</h1>
      <p className="mt-2 text-steel">O endereço não existe neste shell.</p>
      <Link to="/" className="mt-4 inline-block font-medium underline">Voltar ao início</Link>
    </div>
  )
}

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Sprint />} />
        <Route path="hmi" element={<Hmi />} />
        <Route path="orders" element={<Optional name="Ordens"><Orders /></Optional>} />
        <Route path="dashboard" element={<Optional name="Dashboard"><Dashboard /></Optional>} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  )
}
