// Dados simulados. Substituir por chamadas ao API Gateway quando o contrato OpenAPI for aprovado.

export const STATUS_OPTIONS = ['Pendente', 'PASS', 'PASS WITH LIMITATION', 'BLOCKED', 'FAIL']

export const GROUPS = [
  {
    id: 'g1',
    name: 'Grupo 1 — IoT / CLP S7-1200',
    items: [
      'Leitura S7 local comparada à lista real de tags aprovada (ou bloqueio formalizado)',
      'Nenhuma escrita no CLP; flow sem credenciais',
      'Tabela de tags revisada pelo responsável da automação',
    ],
  },
  {
    id: 'g2',
    name: 'Grupo 2 — Cobot, RabbitMQ e QR',
    items: [
      'RabbitMQ local saudável (rabbitmq-diagnostics ping OK)',
      'Mensagem de teste publicada e consumida com o mesmo request_id',
      'QR sintético capturado e decodificado; nenhuma tarefa enviada ao robô',
    ],
  },
  {
    id: 'g3',
    name: 'Grupo 3 — DDL no Neon',
    items: [
      'DDL executado somente em branch de desenvolvimento',
      'Quatro ENUMs e seis tabelas verificados por consulta',
      'Índice idx_telemetry_timestamp (timestamp DESC) confirmado',
      'Decisão registrada: Safety vs emergência e unidade da velocidade',
    ],
  },
  {
    id: 'g4',
    name: 'Grupo 4 — React, Vite e Tailwind',
    items: [
      'Dev server inicia e Tailwind aparece no layout',
      'Quatro rotas e fallback 404 verificados',
      'npm run build verde; nenhum segredo em variável VITE_',
    ],
  },
  {
    id: 'g5',
    name: 'Grupo 5 — OpenAPI, CI e JWT',
    items: [
      'OpenAPI v1 candidata aprovada pelos cinco líderes; lint sem erros estruturais',
      'Monorepo e pipeline base ativos; nenhum segredo no Git',
      'Matriz 401 / 403 / 2xx documentada e roles aprovadas',
      'Tokens de teste distribuídos por canal seguro, com validade curta',
    ],
  },
]

export const ORDERS = [
  { id: 'OP-1001', product: 'Peça A — cinza', qty: 40, done: 40, status: 'Concluída' },
  { id: 'OP-1002', product: 'Peça B — preta', qty: 25, done: 14, status: 'Em produção' },
  { id: 'OP-1003', product: 'Peça A — cinza', qty: 60, done: 0, status: 'Pendente' },
  { id: 'OP-1004', product: 'Peça C — metálica', qty: 15, done: 15, status: 'Concluída' },
  { id: 'OP-1005', product: 'Peça B — preta', qty: 30, done: 0, status: 'Pendente' },
  { id: 'OP-1006', product: 'Peça C — metálica', qty: 20, done: 6, status: 'Cancelada' },
]

export const OEE = {
  availability: 0.91,
  performance: 0.84,
  quality: 0.97,
  hourly: [
    { h: '08h', oee: 0.62 },
    { h: '09h', oee: 0.71 },
    { h: '10h', oee: 0.78 },
    { h: '11h', oee: 0.69 },
    { h: '12h', oee: 0.41 },
    { h: '13h', oee: 0.74 },
    { h: '14h', oee: 0.8 },
    { h: '15h', oee: 0.76 },
  ],
}
