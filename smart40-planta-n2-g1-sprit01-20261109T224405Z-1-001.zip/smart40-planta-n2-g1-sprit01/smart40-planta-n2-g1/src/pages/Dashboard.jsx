import { OEE } from '../data.js'

const pct = (v) => `${Math.round(v * 100)}%`

export default function Dashboard() {
  const total = OEE.availability * OEE.performance * OEE.quality
  const factors = [
    ['Disponibilidade', OEE.availability],
    ['Desempenho', OEE.performance],
    ['Qualidade', OEE.quality],
  ]

  return (
    <div>
      <h1 className="font-display text-4xl font-bold">Dashboard OEE</h1>
      <p className="mt-2 max-w-prose text-steel">
        OEE = disponibilidade × desempenho × qualidade. Valores de exemplo; métricas e unidades finais dependem do contrato MES.
      </p>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <section className="rounded-lg bg-ink p-6 text-paper">
          <h2 className="text-sm text-paper/70">OEE do turno (simulado)</h2>
          <p className="mt-2 font-display text-7xl font-bold leading-none">{pct(total)}</p>
          <p className="mt-3 text-sm text-paper/70">{pct(OEE.availability)} × {pct(OEE.performance)} × {pct(OEE.quality)}</p>
        </section>

        <section className="rounded-lg border border-line bg-panel p-6 lg:col-span-2">
          <h2 className="font-display text-2xl font-bold">Componentes</h2>
          <ul className="mt-4 space-y-4">
            {factors.map(([name, v]) => (
              <li key={name}>
                <div className="flex justify-between text-sm"><span>{name}</span><strong>{pct(v)}</strong></div>
                <div className="mt-1 h-3 overflow-hidden rounded bg-line">
                  <div className="h-full bg-ok" style={{ width: pct(v) }} />
                </div>
              </li>
            ))}
          </ul>
        </section>
      </div>

      <section className="mt-6 rounded-lg border border-line bg-panel p-6">
        <h2 className="font-display text-2xl font-bold">OEE por hora</h2>
        <div className="mt-5 flex h-48 items-end gap-3" role="img" aria-label="Gráfico de barras do OEE por hora">
          {OEE.hourly.map(({ h, oee }) => (
            <div key={h} className="flex h-full flex-1 flex-col justify-end">
              <span className="mb-1 text-center text-xs tabular-nums">{pct(oee)}</span>
              <div className={`rounded-t ${oee < 0.5 ? 'bg-alarm' : 'bg-amber'}`} style={{ height: `${oee * 100}%` }} />
              <span className="mt-1 text-center text-xs text-steel">{h}</span>
            </div>
          ))}
        </div>
        <p className="mt-3 text-xs text-steel">Barras vermelhas indicam OEE abaixo de 50%.</p>
      </section>
    </div>
  )
}
