import { useReducer, useState } from 'react'

const STATE_LABEL = {
  STOPPED: 'Parada',
  RUNNING: 'Em operação',
  FAULT: 'Falha',
  EMERGENCY: 'Emergência',
}

const stateTone = {
  STOPPED: 'bg-steel text-white',
  RUNNING: 'bg-ok text-white',
  FAULT: 'bg-amber text-ink',
  EMERGENCY: 'bg-alarm text-white',
}

function reducer(s, a) {
  const log = (msg) => [{ t: new Date().toISOString(), msg }, ...s.log].slice(0, 8)
  switch (a.type) {
    case 'start':
      if (s.estop || s.state === 'RUNNING') return s
      return { ...s, state: 'RUNNING', log: log('Start (simulado)') }
    case 'stop':
      if (s.state !== 'RUNNING') return s
      return { ...s, state: 'STOPPED', log: log('Stop (simulado)') }
    case 'reset':
      if (s.estop) return { ...s, log: log('Reset recusado: emergência ainda acionada') }
      return { ...s, state: 'STOPPED', log: log('Reset (simulado)') }
    case 'estop':
      return a.value
        ? { ...s, estop: true, state: 'EMERGENCY', log: log('Emergência acionada (simulada)') }
        : { ...s, estop: false, log: log('Emergência liberada; faça Reset') }
    case 'safety':
      return { ...s, safety: a.value, log: log(`Segurança ${a.value ? 'ativa' : 'inativa'} (simulada)`) }
    default:
      return s
  }
}

function Lamp({ on, color, label }) {
  return (
    <div className="flex items-center gap-2">
      <span className={`h-4 w-4 rounded-full border border-ink/40 ${on ? color : 'bg-line'}`} />
      <span className="text-sm">{label}: <strong>{on ? 'acionado' : 'normal'}</strong></span>
    </div>
  )
}

export default function Hmi() {
  const [s, dispatch] = useReducer(reducer, { state: 'STOPPED', estop: false, safety: false, log: [] })
  const [setpoint, setSetpoint] = useState(250)
  const speed = s.state === 'RUNNING' ? setpoint : 0

  const btn = 'rounded px-5 py-3 text-base font-semibold disabled:opacity-40'

  return (
    <div>
      <h1 className="font-display text-4xl font-bold">IHM simulada</h1>
      <p className="mt-2 max-w-prose text-steel">
        Painel de teste do shell. Nenhum botão envia comando real; tudo acontece na memória deste navegador.
      </p>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <section className="rounded-lg border border-line bg-panel p-5 lg:col-span-2">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="font-display text-2xl font-bold">Esteira</h2>
            <span className={`rounded px-3 py-1 text-sm font-semibold ${stateTone[s.state]}`}>
              {STATE_LABEL[s.state]}
            </span>
          </div>

          <div className="mt-5">
            <div
              className="belt"
              style={{ animation: speed ? `belt ${Math.max(0.15, 28 / speed)}s linear infinite` : 'none' }}
              aria-hidden="true"
            />
            <p className="mt-3 text-3xl font-display font-bold">{speed} <span className="text-lg font-medium text-steel">mm/s</span></p>
            <p className="text-xs text-steel">Unidade provisória (mm/s). Fechar a decisão no contrato antes de integrar.</p>
          </div>

          <div className="mt-5">
            <label htmlFor="sp" className="text-sm font-medium">Velocidade desejada: {setpoint} mm/s</label>
            <input id="sp" type="range" min="0" max="500" step="10" value={setpoint}
              onChange={(e) => setSetpoint(Number(e.target.value))}
              className="mt-1 block w-full accent-amber" />
          </div>

          <div className="mt-6 flex flex-wrap gap-3">
            <button className={`${btn} bg-ok text-white`} disabled={s.estop || s.state === 'RUNNING'} onClick={() => dispatch({ type: 'start' })}>Start</button>
            <button className={`${btn} bg-ink text-white`} disabled={s.state !== 'RUNNING'} onClick={() => dispatch({ type: 'stop' })}>Stop</button>
            <button className={`${btn} border border-ink`} onClick={() => dispatch({ type: 'reset' })}>Reset</button>
          </div>
        </section>

        <section className="rounded-lg border border-line bg-panel p-5">
          <h2 className="font-display text-2xl font-bold">Sinais de segurança</h2>
          <p className="mt-1 text-xs text-steel">Segurança e Emergência são sinais distintos até a automação confirmar o significado físico.</p>
          <div className="mt-4 space-y-3">
            <Lamp on={s.safety} color="bg-amber" label="Segurança" />
            <Lamp on={s.estop} color="bg-alarm" label="Emergência" />
          </div>
          <div className="mt-5 flex flex-col gap-2">
            <button className="rounded border border-ink px-3 py-2 text-sm" onClick={() => dispatch({ type: 'safety', value: !s.safety })}>
              Simular Segurança: {s.safety ? 'desativar' : 'ativar'}
            </button>
            <button className="rounded border border-alarm px-3 py-2 text-sm text-alarm" onClick={() => dispatch({ type: 'estop', value: !s.estop })}>
              Simular Emergência: {s.estop ? 'liberar' : 'acionar'}
            </button>
          </div>
        </section>
      </div>

      <section className="mt-6 rounded-lg border border-line bg-panel p-5">
        <h2 className="font-display text-2xl font-bold">Eventos</h2>
        {s.log.length === 0 ? (
          <p className="mt-2 text-sm text-steel">Nenhum evento ainda. Use Start, Stop ou Reset para gerar registros.</p>
        ) : (
          <ul className="mt-3 divide-y divide-line text-sm">
            {s.log.map((e, i) => (
              <li key={i} className="flex flex-wrap gap-3 py-2">
                <time className="text-steel tabular-nums">{e.t}</time>
                <span>{e.msg}</span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  )
}
