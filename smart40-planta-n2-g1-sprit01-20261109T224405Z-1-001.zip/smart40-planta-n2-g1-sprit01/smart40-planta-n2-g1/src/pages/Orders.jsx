import { useState } from 'react'
import { ORDERS } from '../data.js'

const FILTERS = ['Todas', 'Pendente', 'Em produção', 'Concluída', 'Cancelada']

const chip = {
  Pendente: 'bg-steel/15 text-ink',
  'Em produção': 'bg-amber/30 text-ink',
  Concluída: 'bg-ok/15 text-ok',
  Cancelada: 'bg-alarm/15 text-alarm',
}

export default function Orders() {
  const [filter, setFilter] = useState('Todas')
  const rows = filter === 'Todas' ? ORDERS : ORDERS.filter((o) => o.status === filter)

  return (
    <div>
      <h1 className="font-display text-4xl font-bold">Ordens de produção</h1>
      <p className="mt-2 max-w-prose text-steel">Lista de exemplo para validar o layout. Os dados reais virão do módulo MES após a aprovação do contrato.</p>

      <div className="mt-5 flex flex-wrap gap-2" role="group" aria-label="Filtrar por status">
        {FILTERS.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            aria-pressed={filter === f}
            className={'rounded px-3 py-1.5 text-sm font-medium border ' + (filter === f ? 'border-ink bg-ink text-paper' : 'border-line bg-white')}
          >
            {f}
          </button>
        ))}
      </div>

      <div className="mt-5 overflow-x-auto rounded-lg border border-line bg-panel">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-line bg-white">
            <tr>
              <th className="p-3 font-semibold">Ordem</th>
              <th className="p-3 font-semibold">Produto</th>
              <th className="p-3 font-semibold">Progresso</th>
              <th className="p-3 font-semibold">Status</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && (
              <tr><td colSpan="4" className="p-4 text-steel">Nenhuma ordem com este status.</td></tr>
            )}
            {rows.map((o) => (
              <tr key={o.id} className="border-b border-line last:border-0">
                <td className="p-3 font-medium">{o.id}</td>
                <td className="p-3">{o.product}</td>
                <td className="p-3">
                  <div className="flex items-center gap-3">
                    <div className="h-2 w-28 overflow-hidden rounded bg-line">
                      <div className="h-full bg-amber" style={{ width: `${(o.done / o.qty) * 100}%` }} />
                    </div>
                    <span className="tabular-nums">{o.done}/{o.qty}</span>
                  </div>
                </td>
                <td className="p-3"><span className={`rounded px-2 py-1 text-xs font-semibold ${chip[o.status]}`}>{o.status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
