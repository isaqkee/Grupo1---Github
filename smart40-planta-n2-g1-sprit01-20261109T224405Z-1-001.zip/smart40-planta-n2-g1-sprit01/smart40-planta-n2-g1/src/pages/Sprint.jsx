import { useEffect, useState } from 'react'
import { useOutletContext } from 'react-router'
import { GROUPS, STATUS_OPTIONS } from '../data.js'

const KEY = 'smart40:sprint1:status'

function load() {
  try {
    return JSON.parse(localStorage.getItem(KEY)) || {}
  } catch {
    return {}
  }
}

const tone = {
  PASS: 'border-ok bg-ok/10',
  'PASS WITH LIMITATION': 'border-amber bg-amber/15',
  BLOCKED: 'border-alarm bg-alarm/10',
  FAIL: 'border-alarm bg-alarm/10',
  Pendente: 'border-line bg-white',
}

export default function Sprint() {
  const { extras } = useOutletContext()
  const [status, setStatus] = useState(load)
  const groups = extras ? GROUPS : GROUPS.filter((g) => g.id === 'g1')

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(status))
    } catch {
      /* armazenamento indisponível: segue sem persistir */
    }
  }, [status])

  const all = groups.flatMap((g) => g.items.map((_, i) => `${g.id}-${i}`))
  const passed = all.filter((k) => status[k] === 'PASS' || status[k] === 'PASS WITH LIMITATION').length

  return (
    <div>
      <h1 className="font-display text-4xl font-bold">Checklist do Marco 1</h1>
      <p className="mt-2 max-w-prose text-steel">
        Marque o resultado de cada critério de aceite. Sem leitura autorizada do CLP, use BLOCKED ou PASS WITH LIMITATION, nunca PASS. O estado fica salvo apenas neste navegador.{!extras && ' Mostrando só o Grupo 1; ative os módulos opcionais para ver os demais grupos.'}
      </p>

      <div className="mt-5 flex items-center gap-4">
        <div className="h-3 w-full max-w-sm overflow-hidden rounded bg-line" role="progressbar" aria-valuenow={passed} aria-valuemin={0} aria-valuemax={all.length}>
          <div className="h-full bg-ok" style={{ width: `${(passed / all.length) * 100}%` }} />
        </div>
        <p className="text-sm font-medium">{passed} de {all.length} critérios atendidos</p>
        <button
          onClick={() => setStatus({})}
          className="ml-auto rounded border border-line px-3 py-1.5 text-sm hover:bg-white"
        >
          Limpar marcações
        </button>
      </div>

      <div className="mt-8 grid gap-6 md:grid-cols-2">
        {groups.map((g) => (
          <section key={g.id} className="rounded-lg border border-line bg-panel p-5">
            <h2 className="font-display text-2xl font-bold">{g.name}</h2>
            <ul className="mt-4 space-y-3">
              {g.items.map((text, i) => {
                const k = `${g.id}-${i}`
                const value = status[k] || 'Pendente'
                return (
                  <li key={k} className={`rounded border-l-4 p-3 ${tone[value]}`}>
                    <label htmlFor={k} className="block text-sm">{text}</label>
                    <select
                      id={k}
                      value={value}
                      onChange={(e) => setStatus({ ...status, [k]: e.target.value })}
                      className="mt-2 rounded border border-line bg-white px-2 py-1 text-sm"
                    >
                      {STATUS_OPTIONS.map((o) => (
                        <option key={o}>{o}</option>
                      ))}
                    </select>
                  </li>
                )
              })}
            </ul>
          </section>
        ))}
      </div>
    </div>
  )
}
