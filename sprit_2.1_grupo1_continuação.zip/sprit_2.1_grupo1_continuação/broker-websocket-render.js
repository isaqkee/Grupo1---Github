/**
 * broker-websocket-render.js
 * WebSocket Broker para Deploy na Nuvem (Render / Railway)
 * 
 * Atua como intermediário seguro entre o Node-RED (Bancada Física) e a SPA Web (Vercel).
 * Implementa Heartbeat (Ping/Pong), Broadcast de Telemetria e Roteamento de Comandos.
 */

const http = require('http');
const WebSocket = require('ws');

const PORT = process.env.PORT || 8080;

// Criar Servidor HTTP para respostas de Health Check do Render
const server = http.createServer((req, res) => {
    if (req.url === '/health' || req.url === '/') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
            status: 'online',
            service: 'Smart 4.0 WebSocket Broker',
            uptime: process.uptime(),
            timestamp: new Date().toISOString()
        }));
    } else {
        res.writeHead(404);
        res.end();
    }
});

// Instanciar WebSocket Server atrelado ao Servidor HTTP
const wss = new WebSocket.Server({ server, path: '/ws' });

console.log(`[Broker Render] Iniciando servidor na porta ${PORT}...`);

// Mecanismo de Heartbeat (Ping/Pong para manter conexões ativas)
function heartbeat() {
    this.isAlive = true;
}

const interval = setInterval(() => {
    wss.clients.forEach((ws) => {
        if (ws.isAlive === false) {
            console.log(`[Broker] Encerrando conexão inativa (timeout ping)`);
            return ws.terminate();
        }
        ws.isAlive = false;
        ws.ping();
    });
}, 30000);

wss.on('connection', (ws, req) => {
    ws.isAlive = true;
    ws.on('pong', heartbeat);

    const clientIp = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
    console.log(`[Broker] Cliente conectado. IP: ${clientIp} | Total clientes: ${wss.clients.size}`);

    ws.on('message', (message) => {
        try {
            const rawText = message.toString();
            // Retransmite (Broadcast) para todos os outros clientes conectados
            wss.clients.forEach((client) => {
                if (client.readyState === WebSocket.OPEN) {
                    client.send(rawText);
                }
            });
        } catch (err) {
            console.error('[Broker Error] Erro ao retransmitir mensagem:', err.message);
        }
    });

    ws.on('close', () => {
        console.log(`[Broker] Cliente desconectado. Total restantes: ${wss.clients.size}`);
    });

    ws.on('error', (err) => {
        console.error(`[Broker Client Error]:`, err.message);
    });
});

wss.on('close', () => {
    clearInterval(interval);
});

server.listen(PORT, () => {
    console.log(`==================================================`);
    console.log(`[Broker Render] Servidor ativo e rodando na porta ${PORT}`);
    console.log(`[Broker Render] Endpoint WebSocket: ws://<sua-app>.onrender.com/ws`);
    console.log(`==================================================`);
});

// Tratamento de encerramento gracioso
process.on('SIGTERM', () => {
    console.log('SIGTERM recebido. Encerrando broker...');
    server.close(() => {
        process.exit(0);
    });
});
