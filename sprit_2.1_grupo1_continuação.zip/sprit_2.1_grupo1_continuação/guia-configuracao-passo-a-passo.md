# Guia Passo a Passo: Configuração, Simulação e Deploy do Ecossistema Node-RED

Este manual prático guia a equipe de automação do **Grupo 1** na instalação, simulação local e implantação em produção do fluxo Node-RED, atuando como a ponte de comunicação ("porteiro bilíngue") entre os CLPs Siemens S7-1200/1500, o SCADA Elipse e a interface web (SPA) via nuvem.

---

## 1. Visão Geral da Arquitetura de Comunicação

O fluxo Node-RED foi projetado para integrar três redes distintas com taxas de amostragem e protocolos diferentes:

*   **Comunicação Local S7 (CLPs Siemens):** Leitura direta via protocolo S7 nos IPs `192.168.150.10` a `.40` a cada 500 ms.
*   **Comunicação Local HTTP (SCADA Elipse):** Consulta REST GET na porta 4321 a cada 2 segundos.
*   **Comunicação em Nuvem WebSocket (Render / SPA):** Envio de dados consolidados e recepção de comandos remotos via canal `/ws`.

Para evitar que a interface gráfica da SPA receba dados parciais e sofra piscamentos (*flickering*), os trilhos de leitura gravam suas respostas diretamente no contexto global (`context.global`), delegando a publicação a um nó consolidador exclusivo disparado a cada 500 ms.

---

## 2. Pré-requisitos de Software e Dependências

Antes de iniciar a configuração, certifique-se de que o ambiente de desenvolvimento possua as seguintes ferramentas instaladas:

### 2.1. Softwares Necessários
*   **Node.js:** Versão 18.x LTS ou superior.
*   **Node-RED:** Instalado globalmente via linha de comando.
*   **Git:** Para controle de versão e deploy no Render.

### 2.2. Instalação do Node-RED e Módulos
No terminal do seu sistema operacional, execute os comandos abaixo para instalar o Node-RED e o módulo de comunicação Siemens S7:

```bash
# Instalação global do Node-RED
npm install -g node-red

# Inicialização do Node-RED para criação do diretório de usuários (~/.node-red)
node-red
```

Após iniciar o Node-RED pela primeira vez, abra o navegador em `http://localhost:1880`, acesse o **Menu -> Manage palette -> aba Install**, busque por `node-red-contrib-s7` e clique em **Install**. Alternativamente, execute no terminal:

```bash
cd ~/.node-red
npm install node-red-contrib-s7
```

### 2.3. Dependências para os Servidores Node.js (`mock` e `broker`)
Os scripts de simulação e broker utilizam o módulo nativo do Node.js e a biblioteca `ws`. Em uma pasta dedicada aos scripts, instale a dependência:

```bash
npm install ws
```

---

## 3. Fase 1: Simulação Local e Testes Sem Bancada Física

Você pode testar toda a lógica de negócio, o empacotamento do JSON e a integração com a SPA sem estar conectado aos equipamentos físicos da bancada.

### Passo 1: Iniciar o Servidor de Simulação (`mock-server-smart40.js`)
O script `mock-server-smart40.js` emula simultaneamente a API do SCADA Elipse (porta 4321) e o Broker WebSocket (porta 8080).

1. Abra um terminal na pasta onde o arquivo foi salvo.
2. Execute o servidor:
   ```bash
   node mock-server-smart40.js
   ```
3. O terminal exibirá as confirmações:
   * `[MOCK ELIPSE] Servidor HTTP rodando na porta 4321...`
   * `[MOCK BROKER] Servidor WebSocket rodando na porta 8080...`

### Passo 2: Importar o Fluxo no Node-RED
1. Certifique-se de que o Node-RED está em execução (`node-red` no terminal).
2. Acesse `http://localhost:1880`.
3. Vá em **Menu -> Import -> Clipboard**.
4. Abra o arquivo `node-red-flow-grupo1.json`, copie todo o seu conteúdo e cole na caixa de texto.
5. Clique em **Import** e posicione o fluxo na tela de trabalho.

### Passo 3: Adaptar o Fluxo para Modo Teste (Injects Temporários)
Para simular a leitura do CLP sem o hardware físico:
1. Desative ou desconecte temporariamente a saída dos nós `s7 in`.
2. Dobre o clique no nó de pulso `pulso 500ms` ou crie um nó `inject` com o seguinte payload JSON de teste:
   * **Topic:** `CLP_Estoque`
   * **Payload:** `{"statusEstoqueOk": true, "emergenciaEstoque": false, "motorEsteira1": true, "posEstoque": 5}`
3. Ligue este nó `inject` diretamente na entrada do nó `montarTelemetria`.
4. Clique em **Deploy** no canto superior direito.

### Passo 4: Validar a Publicação e Leitura de Dados
1. Abra o painel lateral de Debug no Node-RED (ícone de inseto).
2. Observe que a cada 500 ms o nó `consolidar` monta a estrutura completa da telemetria e repassa para o `websocket out`.
3. Verifique no terminal do `mock-server-smart40.js` se as mensagens WebSocket estão chegando sem erros.

---

## 4. Fase 2: Implantação e Operação na Bancada Industrial Real

Quando os equipamentos físicos estiverem disponíveis, siga estes passos para colocar o sistema em produção.

### Passo 1: Configuração Obrigatória no TIA Portal (CLPs Siemens)
Sem esta configuração, o Node-RED consegue estabelecer conexão de rede com o CLP, mas as leituras de DB retornarão vazias ou com erro de permissão.

1. Abra o projeto da bancada no **Siemens TIA Portal**.
2. Selecione o CLP (ex.: CPU 1214C DC/DC/DC).
3. Vá em **Properties -> Protection & Security -> Connection mechanisms**.
4. Marque a caixa de seleção: **"Permit access with PUT/GET communication from remote partner"**.
5. Em cada Bloco de Dados (DB1), certifique-se de desmarcar a opção *"Optimized block access"* para que os offsets numéricos (`DB1,X0.0`, `DB1,B2`) fiquem acessíveis.
6. Faça o *Compile & Download to Device* em todos os 4 CLPs.

### Passo 2: Deploy do Broker WebSocket na Nuvem (Render)
A hospedagem do front-end Vercel não aceita conexões WebSocket de entrada. Portanto, a comunicação deve utilizar o script do broker WebSocket em um serviço de nuvem como Render ou Railway.

1. Crie um repositório no GitHub contendo o arquivo `broker-websocket-render.js` e o arquivo `package.json`.
2. Acesse a plataforma de hospedagem em nuvem (ex.: Render) e crie um novo serviço web.
3. Conecte o repositório do projeto.
4. Configure os comandos de execução:
   * **Ambiente:** Node.js
   * **Comando de Build:** `npm install`
   * **Comando de Inicialização:** `node broker-websocket-render.js`
5. Finalize a implantação e copie o endereço WebSocket seguro fornecido pela plataforma.

### Passo 3: Reconfigurar os Nós de Rede no Node-RED
1. No Node-RED, abra a configuração dos endpoints dos nós `s7 in` e `s7 out` e insira os IPs reais da rede local:
   * **CLP Estoque:** `192.168.150.10`
   * **CLP Processo:** `192.168.150.20`
   * **CLP Montagem:** `192.168.150.30`
   * **CLP Expedição:** `192.168.150.40`
   * **Rack:** `0` | **Slot:** `1`
2. Abra a configuração do nó `websocket out` ("publicar telemetria"):
   * Selecione **Connect to** (Client).
   * Insira a URL pública do broker WebSocket hospedado na nuvem.
3. Abra a configuração do nó `http request` ("consultar Elipse"):
   * URL: `http://192.168.150.200:4321/api/Events/order/current`
4. Clique em **Deploy**.

---

## 5. Resolução de Problemas (Troubleshooting FAQ)

| Sintoma / Erro | Causa Provável | Solução Recomendada |
| :--- | :--- | :--- |
| **Nó S7 fica amarelo ("Connecting") ou vermelho ("Bad Value")** | IP inalcançável ou cabo desconectado. | Testar o comando `ping 192.168.150.10` no terminal. Verificar a máscara de sub-rede do computador. |
| **Nó S7 fica verde ("Connected"), mas não lê as variáveis** | Permissão PUT/GET desativada no TIA Portal. | No TIA Portal, marcar "Permit access with PUT/GET" e regravar as configurações no CLP. |
| **A SPA recebe mensagens infinitas em loop curto** | O nó `websocket in` capturou o eco da telemetria enviada pelo `websocket out`. | Confirmar se o nó `validarComando` contém o filtro `if (msg.payload && msg.payload.roboUR) return null;`. |
| **A tela da SPA pisca e exibe estados incompletos** | Um dos trilhos de leitura está publicando diretamente no WebSocket. | Garantir que `montarTelemetria` e `gravarPedido` terminem com `return null;`. Apenas o nó `consolidar` deve publicar. |
| **Comandos de parada de emergência não funcionam** | O filtro de origem bloqueou a mensagem. | Verificar se o comando possui a ação `EMERGENCY_STOP`. Esta ação é tratada incondicionalmente no nó `validarComando`. |
| **Conexão WebSocket caindo na nuvem a cada poucas minutos** | Timeout de inatividade do servidor proxy na nuvem. | Garantir que o script do broker na nuvem esteja executando o *ping/pong heartbeat* a cada 30 segundos. |
