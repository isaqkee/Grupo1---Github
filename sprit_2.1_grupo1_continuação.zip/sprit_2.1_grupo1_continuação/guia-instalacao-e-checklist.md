# Guia Prático e Manual de Implantação — Node-RED para Automação Industrial (Grupo 1)

Este manual orienta o **Grupo 1** na instalação, configuração, validação e operação do fluxo **Node-RED** para a bancada de automação da fábrica inteligente (Smart 4.0).

---

## 1. Arquitetura do Sistema ("Porteiro Bilíngue")

O Node-RED atua como o tradutor central entre o hardware físico da fábrica e a nuvem:
* **Entradas Locais:** Protocolo **Siemens S7** (CLPs) e **HTTP REST** (SCADA Elipse).
* **Saída Nuvem:** **WebSocket (`/ws`)** conectado ao Broker no Render.

### Os 4 Trilhos Independentes:
1. **Trilho 1 — Leitura dos CLPs (500 ms):** Dispara a cada 500ms, lê os 4 CLPs via `s7 in`, executa `montarTelemetria` e grava no `context.global` (retorna `null` sem publicar).
2. **Trilho 2 — Leitura do SCADA Elipse (2 s):** Dispara a cada 2s via `http request`, grava dados de pedidos no `context.global` (retorna `null`).
3. **Trilho 3 — Comandos da Nuvem:** Recebe comandos via `websocket in`, valida com `validarComando` (evita eco e checa origem), roteia com `switch` e escreve nos CLPs via `s7 out`.
4. **Trilho 4 — Consolidação e Publicação (500 ms):** O nó `consolidar` resgata o estado completo do `context.global`, atualiza o *timestamp* e publica uma única mensagem limpa via `websocket out`.

---

## 2. Passo a Passo de Instalação e Importação

### Passo 1: Instalar dependência S7 no Node-RED
1. Abra a interface do Node-RED no navegador (`http://localhost:1880`).
2. Clique no Menu Superior (canto superior direito) → **Manage palette**.
3. Selecione a aba **Install**.
4. Pesquise por `node-red-contrib-s7` e clique em **Install**.

### Passo 2: Importar o Fluxo JSON
1. Abra o arquivo `node-red-flow-grupo1.json`.
2. Copie todo o conteúdo JSON.
3. No Node-RED, vá no Menu Superior → **Import** → **Clipboard**.
4. Cole o código JSON e clique em **Import**.
5. Clique no botão vermelho **Deploy** no canto superior direito.

---

## 3. Checklist Pré-Operacional de Validação (5 Pontos Críticos)

Antes de rodar o fluxo com a bancada física energizada, confirme impreterivelmente estes 5 itens:

- [ ] **1. PUT/GET Habilitado nos CLPs Siemens (TIA Portal):**
  * Em cada um dos 4 CLPs no TIA Portal: *Properties* → *Protection & Security* → *Connection mechanisms* → Marcar **"Permit access with PUT/GET communication from remote partner"**.
  * *Se omitido: O nó `s7 in` conectará mas não lerá nenhum dado.*

- [ ] **2. Teste de Conectividade de Rede (IPs):**
  * Abra o terminal do computador e execute testes de `ping`:
    ```bash
    ping 192.168.150.10 # CLP Estoque
    ping 192.168.150.20 # CLP Processo
    ping 192.168.150.30 # CLP Montagem
    ping 192.168.150.40 # CLP Expedição
    ping 192.168.150.200 # SCADA Elipse
    ```

- [ ] **3. Pacote S7 Instalado:**
  * Verificar se os nós `s7 in` e `s7 out` aparecem sem erros de nó não reconhecido.

- [ ] **4. Caminho `/ws` Exclusivo:**
  * Certifique-se de que nenhum outro fluxo no Node-RED está usando a rota `/ws` para evitar conflito de socket.

- [ ] **5. Apontamento Correto do WebSocket (Broker no Render):**
  * **ATENÇÃO:** O nó `websocket out` deve apontar para o servidor Broker na nuvem (Render/Railway). **NUNCA** aponte direto para a Vercel, pois a Vercel não aceita conexões WebSocket de entrada.

---

## 4. Como Testar sem a Bancada Física (Simulação)

Para testar a integração com a SPA web sem estar conectado à bancada física:
1. Abra a função `montarTelemetria`.
2. Adicione temporariamente um nó `inject` conectado à função `montarTelemetria` com `msg.topic = 'CLP_Estoque'` e `msg.payload = { statusEstoqueOk: true, emergenciaEstoque: false, motorEsteira1: true, posEstoque: 5 }`.
3. Ou execute o arquivo `mock-server-smart40.js` em terminal separado:
   ```bash
   node mock-server-smart40.js
   ```
4. Verifique se a SPA exibe os dados atualizados sem oscilações na interface.

---

## 5. Como Executar os Scripts de Apoio

* **Servidor Mock Local:** `node mock-server-smart40.js`
* **Broker WebSocket (Render):** Deploy no Render utilizando o arquivo `broker-websocket-render.js` e definindo `PORT` nas variáveis de ambiente.
