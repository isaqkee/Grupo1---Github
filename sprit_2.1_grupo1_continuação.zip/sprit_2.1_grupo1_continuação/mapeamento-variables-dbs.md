# Mapeamento Completo de Variáveis e Comunicação — Bancada Smart 4.0 (Grupo 1)

Este documento descreve o endereçamento detalhado dos Blocos de Dados (DBs) nos CLPs Siemens S7-1200/1500, os endpoints do SCADA Elipse e o contrato de dados JSON utilizado para comunicação entre a bancada física e a nuvem via Node-RED.

---

## 1. Tabela de Endereçamento dos CLPs Siemens (Protocolo S7)

Todos os CLPs operam no **Rack 0, Slot 1** com porta padrão **102**.

### 1.1 CLP Estoque (IP: `192.168.150.10`)
* **Nó S7 Endpoint:** `CLP_Estoque`
* **Ciclo de Leitura:** 500 ms

| Variável Node-RED | Endereço DB | Tipo de Dado | Direção | Descrição / Função |
| :--- | :--- | :--- | :--- | :--- |
| `statusEstoqueOk` | `DB1,X0.0` | BOOL (Bit) | Leitura | Status operacional da estação (1 = OK, 0 = Falha) |
| `emergenciaEstoque`| `DB1,X0.1` | BOOL (Bit) | Leitura | Botão de emergência acionado na estação (1 = Emergência) |
| `motorEsteira1` | `DB1,X0.2` | BOOL (Bit) | Leitura | Estado do motor da esteira principal (1 = Ligado) |
| `posEstoque` | `DB1,B2` | BYTE (Int 0-255) | Leitura | Posição física ou quantidade de peças no magazine de estoque |
| **Comando START** | `DB1,X0.4` | BOOL (Bit) | Escrita | Pulso para iniciar a esteira / estação de estoque |
| **Comando STOP** | `DB1,X0.5` | BOOL (Bit) | Escrita | Pulso para parar a esteira / estação de estoque |
| **Comando RESET** | `DB1,X0.6` | BOOL (Bit) | Escrita | Pulso de reset de falhas da estação |
| **Comando EMERGENCIA** | `DB1,X0.7` | BOOL (Bit) | Escrita | Ativação do estado de emergência global |

---

### 1.2 CLP Processo (IP: `192.168.150.20`)
* **Nó S7 Endpoint:** `CLP_Processo`
* **Ciclo de Leitura:** 500 ms

| Variável Node-RED | Endereço DB | Tipo de Dado | Direção | Descrição / Função |
| :--- | :--- | :--- | :--- | :--- |
| `statusProcessoOk` | `DB1,X0.0` | BOOL (Bit) | Leitura | Status operacional do módulo de usinagem/processo |
| `emergenciaProcesso`| `DB1,X0.1` | BOOL (Bit) | Leitura | Emergência na estação de processo |
| `posProcesso` | `DB1,B2` | BYTE | Leitura | Posição da peça no magazine de processo |

---

### 1.3 CLP Montagem & Robô UR (IP: `192.168.150.30`)
* **Nó S7 Endpoint:** `CLP_Montagem`
* **Ciclo de Leitura:** 500 ms

| Variável Node-RED | Endereço DB | Tipo de Dado | Direção | Descrição / Função |
| :--- | :--- | :--- | :--- | :--- |
| `statusMontagemOk` | `DB1,X0.0` | BOOL (Bit) | Leitura | Status da estação de montagem |
| `emergenciaMontagem`| `DB1,X0.1` | BOOL (Bit) | Leitura | Emergência na estação de montagem |
| `garraFechada` | `DB1,X0.2` | BOOL (Bit) | Leitura | Status do atuador da garra do Robô UR (1 = Fechada) |
| `posMontagem` | `DB1,B2` | BYTE | Leitura | Posição da peça na montagem |
| `robotX` | `DB1,REAL4` | FLOAT (32-bit) | Leitura | Coordenada X cartesiana do robô (via PROFINET) |
| `robotY` | `DB1,REAL8` | FLOAT (32-bit) | Leitura | Coordenada Y cartesiana do robô (via PROFINET) |
| `robotZ` | `DB1,REAL12` | FLOAT (32-bit) | Leitura | Coordenada Z cartesiana do robô (via PROFINET) |

---

### 1.4 CLP Expedição (IP: `192.168.150.40`)
* **Nó S7 Endpoint:** `CLP_Expedicao`
* **Ciclo de Leitura:** 500 ms

| Variável Node-RED | Endereço DB | Tipo de Dado | Direção | Descrição / Função |
| :--- | :--- | :--- | :--- | :--- |
| `statusExpedicaoOk` | `DB1,X0.0` | BOOL (Bit) | Leitura | Status operacional da rampa de expedição |
| `emergenciaExpedicao`| `DB1,X0.1` | BOOL (Bit) | Leitura | Emergência na estação de expedição |
| `posExpedicao` | `DB1,B2` | BYTE | Leitura | Quantidade/Posição de produtos acabados |

---

## 2. API SCADA Elipse (Protocolo HTTP GET)

* **URL base:** `http://192.168.150.200:4321/api/Events/order/current`
* **Método:** `GET`
* **Ritmo de Consulta:** 2.0 segundos (Nó `pulso Elipse 2s`)

### Exemplo de Resposta JSON do Elipse:
```json
{
  "trackingCode": "ORD-2026-9941",
  "componentId": "PIECE-BLOCK-RED",
  "status": "EM_PRODUCAO"
}
```

---

## 3. Contrato de Telemetria Consolidada (`telemetria`)

Enviado a cada 500 ms via WebSocket (`/ws`) para o Broker na nuvem:

```typescript
interface TelemetriaGlobal {
  timestamp: string; // ISO 8601
  roboUR: {
    posicaoCartesiana: { x: number; y: number; z: number };
    posicaoJuntas: number[];
    garraFechada: boolean;
  };
  esteira: {
    motorLigado: boolean;
    pecaAtual: string | null;
  };
  estacoes: {
    estoque: { status: 'OPERANDO' | 'AGUARDANDO' | 'EMERGENCIA'; magazine: number };
    processo: { status: 'OPERANDO' | 'AGUARDANDO' | 'EMERGENCIA'; magazine: number };
    montagem: { status: 'OPERANDO' | 'AGUARDANDO' | 'EMERGENCIA'; magazine: number };
    expedicao: { status: 'OPERANDO' | 'AGUARDANDO' | 'EMERGENCIA'; magazine: number };
  };
  pedidoAtual: {
    trackingCode: string;
    componentId: string;
    status: string;
  } | null;
}
```

---

## 4. Contrato de Comandos da Nuvem

Estrutura JSON enviada pela SPA/Nuvem via WebSocket para o Node-RED:

```json
{
  "acao": "START | STOP | RESET | EMERGENCY_STOP",
  "origem": "unidade1-grupo1"
}
```
* **Origens Autorizadas:** `unidade1-grupo1` até `unidade1-grupo5`.
* **Regra de Emergência:** `EMERGENCY_STOP` ignora validação de origem e é executado incondicionalmente.
