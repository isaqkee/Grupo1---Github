/**
 * mock-server-smart40.js
 * Servidor de Simulação Local para Automação Industrial (Grupo 1 - Smart 4.0)
 *
 * Este script simula:
 * 1. O servidor SCADA Elipse (API HTTP GET na porta 4321)
 * 2. O Broker / Servidor WebSocket local na porta 8080 (/ws)
 * 3. Gerador de dados de telemetria mock dos 4 CLPs (Estoque, Processo, Montagem, Expedição)
 *
 * Como rodar:
 *   node mock-server-smart40.js
 */

const http = require('http');
const WebSocket = require('ws');

const HTTP_PORT = 4321;
const WS_PORT = 8080;

// Estado da Simulação
let estadoMock = {
    timestamp: new Date().toISOString(),
    roboUR: {
        posicaoCartesiana: { x: 125.4, y: -450.2, z: 310.0 },
        posicaoJuntas: [0.0, -1.57, 1.57, 0.0, 1.57, 0.0],
        garraFechada: false
    },
    esteira: {
        motorLigado: true,
        pecaAtual: "COMP-A1"
    },
    estacoes: {
        estoque: { status: 'OPERANDO', magazine: 8 },
        processo: { status: 'OPERANDO', magazine: 4 },
        montagem: { status: 'OPERANDO', magazine: 2 },
        expedicao: { status: 'AGUARDANDO', magazine: 12 }
    },
    pedidoAtual: {
        trackingCode: "ORD-2026-9941",
        componentId: "PIECE-BLOCK-RED",
        status: "EM_PRODUCAO"
    }
};

// --- 1. SERVIDOR HTTP (Simulando SCADA Elipse) ---
const httpServer = http.createServer((req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Content-Type', 'application/json');

    if (req.method === 'OPTIONS') {
        res.writeHead(204);
        res.end();
        return;
    }

    if (req.url === '/api/Events/order/current' && req.method === 'GET') {
        res.writeHead(200);
        res.end(JSON.stringify(estadoMock.pedidoAtual));
        console.log(`[HTTP SCADA Elipse] GET /api/Events/order/current -> 200 OK`);
    } else {
        res.writeHead(404);
        res.end(JSON.stringify({ error: 'Endpoint nao encontrado' }));
    }
});

httpServer.listen(HTTP_PORT, () => {
    console.log(`\n==================================================`);
    console.log(`[HTTP SCADA Elipse Mock] Rodando em http://localhost:${HTTP_PORT}`);
});

// --- 2. SERVIDOR WEBSOCKET (Simulando Broker / Nuvem) ---
const wss = new WebSocket.Server({ port: WS_PORT, path: '/ws' }, () => {
    console.log(`[WebSocket Broker Mock] Escutando em ws://localhost:${WS_PORT}/ws`);
    console.log(`==================================================\n`);
});

// Broadcast para todos os clientes conectados (SPA, Node-RED, etc.)
function broadcast(data) {
    const payload = typeof data === 'string' ? data : JSON.stringify(data);
    wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(payload);
        }
    });
}

wss.on('connection', (ws, req) => {
    const clientIp = req.socket.remoteAddress;
    console.log(`[WebSocket] Novo cliente conectado de: ${clientIp}`);

    ws.on('message', (message) => {
        try {
            const data = JSON.parse(message);
            console.log(`[WebSocket Rx] Mensagem recebida:`, data);

            // Tratamento de Comandos recebidos da SPA/Nuvem
            if (data.acao) {
                console.log(` >>> COMANDO RECEBIDO: [${data.acao}] de Origem: [${data.origem || 'Desconhecida'}]`);

                if (data.acao === 'EMERGENCY_STOP') {
                    estadoMock.estacoes.estoque.status = 'EMERGENCIA';
                    estadoMock.estacoes.processo.status = 'EMERGENCIA';
                    estadoMock.estacoes.montagem.status = 'EMERGENCIA';
                    estadoMock.estacoes.expedicao.status = 'EMERGENCIA';
                    estadoMock.esteira.motorLigado = false;
                    console.log(` !!! [EMERGENCIA ATIVADA] Todas as estacoes foram paradas!`);
                } else if (data.acao === 'START') {
                    estadoMock.estacoes.estoque.status = 'OPERANDO';
                    estadoMock.esteira.motorLigado = true;
                    console.log(` [START] Esteira e estoque ligados.`);
                } else if (data.acao === 'STOP') {
                    estadoMock.esteira.motorLigado = false;
                    console.log(` [STOP] Esteira desligada.`);
                } else if (data.acao === 'RESET') {
                    estadoMock.estacoes.estoque.status = 'AGUARDANDO';
                    estadoMock.estacoes.processo.status = 'AGUARDANDO';
                    estadoMock.estacoes.montagem.status = 'AGUARDANDO';
                    estadoMock.estacoes.expedicao.status = 'AGUARDANDO';
                    console.log(` [RESET] Status das estacoes redefinido.`);
                }
            }
        } catch (err) {
            console.error(`[WebSocket Error] Erro ao processar JSON recebido:`, err.message);
        }
    });

    ws.on('close', () => {
        console.log(`[WebSocket] Cliente desconectado.`);
    });
});

// Simulação de pulso continuo de telemetria a cada 1 segundo (se testado de forma autônoma)
setInterval(() => {
    estadoMock.timestamp = new Date().toISOString();
    // Variações aleatórias pequenas para demonstrar dinamismo visual na SPA
    if (estadoMock.esteira.motorLigado) {
        estadoMock.roboUR.posicaoCartesiana.x = Number((120 + Math.random() * 10).toFixed(2));
    }
    broadcast(estadoMock);
}, 1000);
